#include "myclass.h"

MyClass::MyClass(QObject *parent)
    : QObject{parent}
{
  qDebug()<<"myclass constructor called"<<Qt::endl;
}

MyClass::MyClass(DeviceProxy *proxy, QObject *parent)
{
    m_proxy=proxy;
    connect(m_proxy,&DeviceProxy::o2LevelChanged,this,&MyClass::RecivedVal);
     connect(m_proxy,&DeviceProxy::o1LevelChanged,this,&MyClass::RecivedVal1);
      connect(m_proxy,&DeviceProxy::heartRateChanged,this,&MyClass::RecivedVal2);
       connect(m_proxy,&DeviceProxy::o3LevelChanged,this,&MyClass::RecivedVal3);
        connect(m_proxy,&DeviceProxy::o4LevelChanged,this,&MyClass::RecivedVal4);
}

MyClass::~MyClass()
{
 qDebug()<<"myclass destructor called"<<Qt::endl;
}
bool MyClass::RecivedVal(int a,int b){
    if (a<b) {
        m_num=a;
        m_num2=b;
        qDebug("a is less than b");
        return true;
    } else {
         qDebug("b is great than a");
         m_num=b;
         m_num2=a;
         return false;
    }
}
bool MyClass::RecivedVal1(int c){
    qDebug("RecivedVal1 called");
    m_num2=c;
    return true;
}
bool MyClass::RecivedVal2(int d){
    qDebug("RecivedVal1 called");
    m_num3=d;
     return true;
}
bool MyClass::RecivedVal3(int e){
    qDebug("RecivedVal1 called");
    m_num4=e;
     return true;
}
bool MyClass::RecivedVal4(int f){
    qDebug("RecivedVal1 called");
    m_num5=f;
    return true;
}
int MyClass::num() const
{
    return m_num;
}

void MyClass::setNum(int newNum)
{
    m_num = newNum;
}

const QString &MyClass::name() const
{
    return m_name;
}

void MyClass::setName(const QString &newName)
{
    m_name = newName;
}

int MyClass::num2() const
{
    return m_num2;
}

void MyClass::setNum2(int newNum2)
{
    m_num2 = newNum2;
}

int MyClass::num3() const
{
    return m_num3;
}

void MyClass::setNum3(int newNum3)
{
    m_num3 = newNum3;
}

int MyClass::num4() const
{
    return m_num4;
}

void MyClass::setNum4(int newNum4)
{
    m_num4 = newNum4;
}

int MyClass::num5() const
{
    return m_num5;
}

void MyClass::setNum5(int newNum5)
{
    m_num5 = newNum5;
}
