#ifndef DEVICEPROXY_H
#define DEVICEPROXY_H

#include <QObject>

class DeviceProxy : public QObject
{
    Q_OBJECT
public:
    explicit DeviceProxy(QObject *parent = nullptr){};
    ~ DeviceProxy(){};

    virtual void setO2Levael(int newO2Levael)=0;

    virtual void setO1Leavel(int newO1Leavel)=0;

    virtual void setO3Levael(int newO3Levael)=0;

    virtual void setO4levael(int newO4levael)=0;

    virtual void setHeartRate(int newHeartRate)=0;

private:
    int m_heartRate;
    int O2Levael;
    int O4levael;
    int O3Levael;
    int O1Leavel;
signals:
    void o1LevelChanged(int);
    void o2LevelChanged(int,int);
    void o3LevelChanged(int);
    void o4LevelChanged(int);
    void heartRateChanged(int);

};


#endif // DEVICEPROXY_H
