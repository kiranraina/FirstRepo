#ifndef MYCLASS_H
#define MYCLASS_H
#include<deviceproxy.h>
#include<QDebug>
#include <QObject>

class MyClass : public QObject
{
    Q_OBJECT
public:
    explicit MyClass(QObject *parent = nullptr);
   explicit MyClass(DeviceProxy *proxy,QObject *parent = nullptr);
    ~MyClass();
    int num() const;
    void setNum(int newNum);
    const QString &name() const;
    void setName(const QString &newName);

    int num2() const;
    void setNum2(int newNum2);

    int num3() const;
    void setNum3(int newNum3);

    int num4() const;
    void setNum4(int newNum4);

    int num5() const;
    void setNum5(int newNum5);

    bool RecivedVal(int a,int b);
    bool RecivedVal1(int c);
    bool RecivedVal2(int d);
    bool RecivedVal3(int e);
    bool RecivedVal4(int f);
signals:
private:
    int m_num;
    int m_num2;
    int m_num3;
    int m_num4;
    int m_num5;
    QString m_name;
    DeviceProxy *m_proxy;

};

#endif // MYCLASS_H
