#include "myclass.h"
#include <QDebug>
#include <gtest/gtest.h>
#include <gmock/gmock-matchers.h>
#include<devicemock.h>
#include <QSignalSpy>
using namespace testing;

class MYClassTest:public::testing::Test
{
public:
    MYClassTest(){
        qDebug()<<"Inside the myclasstest"<<Qt::endl;
    }
    void StepUp(){
        qDebug()<<"Inside the StepUp"<<Qt::endl;
    }
    DeviceMock *devMock=new DeviceMock;
    MyClass *clas=new MyClass(devMock);

};

TEST(TestExample, TestSignal)
{
    DeviceMock *devMock=new DeviceMock;
    QSignalSpy s1(devMock,&DeviceMock::o2LevelChanged);
    QSignalSpy s2(devMock,&DeviceMock::o1LevelChanged);
    QSignalSpy s3(devMock,&DeviceMock::heartRateChanged);
    QSignalSpy s4(devMock,&DeviceMock::o3LevelChanged);
    QSignalSpy s5(devMock,&DeviceMock::o4LevelChanged);
    MyClass *clas=new MyClass(devMock);

    devMock->setO2Levael(100);
    EXPECT_EQ(clas->num(), 100);
    EXPECT_EQ(s1.count(), 1);

    devMock->setO4levael(200);
    EXPECT_EQ(clas->num5(), 200);
    EXPECT_EQ(s5.count(), 1);

    devMock->setO1Leavel(500);
    EXPECT_EQ(clas->num2(), 500);
    EXPECT_EQ(s2.count(), 1);

    devMock->setO3Levael(300);
    EXPECT_EQ(clas->num4(), 300);
    EXPECT_EQ(s4.count(), 1);

    devMock->setHeartRate(400);
    EXPECT_EQ(clas->num3(), 400);
    EXPECT_EQ(s3.count(), 1);

}
//TEST(TestExample, TestCase)
//{
//    MyClass clas;
//    clas.setName("kiran");
//    EXPECT_EQ(clas.name(), "kiran");
//    ASSERT_THAT(0, Eq(0));
//}

