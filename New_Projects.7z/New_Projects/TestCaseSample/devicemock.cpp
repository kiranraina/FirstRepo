#include "devicemock.h"

DeviceMock::DeviceMock(QObject *parent)
    : DeviceProxy{parent}
{
    qDebug()<<"DeviceMock constructor"<<Qt::endl;
}

void DeviceMock::setHeartRate(int newHeartRate)
{
     qDebug()<<"DeviceMock setHeartRate"<<Qt::endl;
     emit heartRateChanged(newHeartRate);
}

void DeviceMock::setO4levael(int newO4levael)
{
qDebug()<<"DeviceMock setO4levael"<<Qt::endl;
emit o4LevelChanged(newO4levael);
 }

void DeviceMock::setO3Levael(int newO3Levael)
{
     qDebug()<<"DeviceMock setO3Levael"<<Qt::endl;
     emit o3LevelChanged(newO3Levael);
}

void DeviceMock::setO1Leavel(int newO1Leavel)
{
     qDebug()<<"DeviceMock setO1Leavel"<<Qt::endl;
     emit o1LevelChanged(newO1Leavel);
}

void DeviceMock::setO2Levael(int newO2Levael)
{
    qDebug()<<"DeviceMock setO2Levael"<<Qt::endl;
    emit o2LevelChanged(newO2Levael,300);
}


