#ifndef DEVICEMOCK_H
#define DEVICEMOCK_H
#include<QDebug>
#include "deviceproxy.h"
#include <QObject>

class DeviceMock : public DeviceProxy
{
    Q_OBJECT
public:
    explicit DeviceMock(QObject *parent = nullptr);

    // DeviceProxy interface
public:
   virtual void setO2Levael(int newO2Levael);
   virtual void setO1Leavel(int newO1Leavel);
   virtual void setO3Levael(int newO3Levael);
   virtual void setO4levael(int newO4levael);
    virtual  void setHeartRate(int newHeartRate);
};



#endif // DEVICEMOCK_H
