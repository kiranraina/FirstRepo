#include <QCoreApplication>
#include"Dynamiclibrary.h"
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
  DynamicLibrary dynamic;
  int val=dynamic.subtraction(10,20);
  cout<<val<<endl;
    return a.exec();
}
