#ifndef SOUNDMODEL_H
#define SOUNDMODEL_H

#include <QObject>

class Soundmodel : public QObject
{
    Q_OBJECT
public:
    explicit Soundmodel(QObject *parent = nullptr);

signals:

};

#endif // SOUNDMODEL_H
