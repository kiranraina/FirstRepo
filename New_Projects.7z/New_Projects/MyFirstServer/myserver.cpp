#include "myserver.h"

MyServer::MyServer(QObject *parent)
    : QObject{parent}
{
  server=new QTcpServer(this);
  connect(server,SIGNAL(newConnection()),this,SLOT(newConnection()));

  if(!server->listen(QHostAddress::Any,1234))
  {
     qDebug()<<"server could not start";
  }else
  {
      qDebug()<<"server started";
  }

}

void MyServer::newConnection()
{
    qInfo()<<"inside new connection"<<Qt::endl;
   socket=server->nextPendingConnection();
   socket->write("hello client\r\n");
   socket->flush();
   socket->waitForBytesWritten(3000);
   connect(socket,SIGNAL(readyRead()),this,SLOT(onReadyRead()));
   //   socket->close();
}

void MyServer::onReadyRead()
{
   qInfo()<<"inside  onReadyRead"<<Qt::endl;
   qDebug()<<socket->readAll();
   socket->write(QByteArray("ok!\n"));
   socket->close();
}
