#include "Rect.h"

Rect::Rect()
{

}
