#include "pluginex_plugin.h"

#include "myitem.h"

#include <qqml.h>

void PluginExPlugin::registerTypes(const char *uri)
{
    // @uri com.radio.helpers
    qmlRegisterType<MyItem>(uri, 1, 0, "MyItem");
}

