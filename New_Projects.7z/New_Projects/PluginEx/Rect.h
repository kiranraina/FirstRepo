#ifndef RECT_H
#define RECT_H

#include <QQuickPaintedItem>

class Rect : public QQuickPaintedItem
{
public:
    Rect();
};

#endif // RECT_H
