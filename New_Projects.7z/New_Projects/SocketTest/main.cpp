#include <QCoreApplication>
#include<sockettest.h>
int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);
    Sockettest cTest;
    cTest.Connect();
    return a.exec();
}
