#include "sockettest.h"

Sockettest::Sockettest(QObject *parent)
    : QObject{parent}
{
   qDebug()<<"constructor client";
}

void Sockettest::Connect()
{
  socket= new QTcpSocket(this);
  socket->connectToHost("voidrealms.com",80);
  if(socket->waitForConnected(3000))
  {
      qDebug()<<"Connected";
      socket->write("hello server\r\n\r\n\r\n\r\n");
      socket->waitForBytesWritten(1000);
      socket->waitForReadyRead(3000);
      qDebug()<<"Reading"<<socket->bytesAvailable();
      qDebug()<<socket->readAll();
      socket->close();
  }
  else
  {
     qDebug()<<"Not Connected";
  }
}
