#ifndef SOCKETTEST_H
#define SOCKETTEST_H

#include <QObject>
#include<QTcpSocket>
#include<QDebug>
class Sockettest : public QObject
{
    Q_OBJECT
public:
    explicit Sockettest(QObject *parent = nullptr);

    void Connect();
signals:
private:
    QTcpSocket *socket;

};

#endif // SOCKETTEST_H
