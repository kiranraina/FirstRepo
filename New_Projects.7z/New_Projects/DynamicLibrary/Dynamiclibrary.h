#ifndef DYNAMICLIBRARY_H
#define DYNAMICLIBRARY_H
#include "iostream"
using namespace std;
#include "DynamicLibrary_global.h"

class DYNAMICLIBRARY_EXPORT DynamicLibrary
{
public:
    DynamicLibrary();
    ~DynamicLibrary();
     int subtraction(int,int);
};

#endif // DYNAMICLIBRARY_H
