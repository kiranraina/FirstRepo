#include "Dynamiclibrary.h"

DynamicLibrary::DynamicLibrary()
{
   cout<<"DynamicLibrary constructor"<<endl;
}
DynamicLibrary::~DynamicLibrary()
{
    cout<<"DynamicLibrary destructor"<<endl;
}

int DynamicLibrary::subtraction(int a, int b)
{
    cout<<"DynamicLibrary subtraction"<<endl;
    return a-b;
}
