#include <iostream>
#include <Staticlib.h>
using namespace std;

int main()
{
    cout << "Hello World!" << endl;
    StaticLib sl;
    int val = sl.addition(2,3);
    cout << "val = " <<val<<endl;

    return 0;
}
