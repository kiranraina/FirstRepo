#ifndef MYCLIENT_H
#define MYCLIENT_H
#include<QTcpSocket>
#include <QObject>
#include<QDebug>
class MyClient : public QObject
{
    Q_OBJECT
public:
    explicit MyClient(QObject *parent = nullptr);
    Q_INVOKABLE void init();
    Q_INVOKABLE void startConnect();
    void dataRecd();
    Q_INVOKABLE void sendData(QString da);

signals:
private:
    QTcpSocket *m_socket;

};

#endif // MYCLIENT_H
