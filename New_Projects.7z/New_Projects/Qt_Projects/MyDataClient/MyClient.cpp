#include "MyClient.h"

MyClient::MyClient(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    init();
}

void MyClient::init()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_socket=new QTcpSocket;
}

void MyClient::startConnect()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    this->m_socket->connectToHost("localhost",8000);
    connect(m_socket,&QTcpSocket::readyRead,
            this,&MyClient::dataRecd);
    m_socket->write("Welcome");
}

void MyClient::sendData(QString da)
{
     qDebug()<<Q_FUNC_INFO<<"helooooooooooooooooooooo"<<Qt::endl;
    m_socket->write(da.toLocal8Bit().constData());
}
void MyClient::dataRecd()
{
    qDebug()<<Q_FUNC_INFO<<m_socket->readAll()<<Qt::endl;
}

