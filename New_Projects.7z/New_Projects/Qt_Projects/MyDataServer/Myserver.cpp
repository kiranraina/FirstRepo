#include "Myserver.h"

MyServer::MyServer(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void MyServer::init()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    this->m_server=new QTcpServer;
    m_server->listen(QHostAddress::Any,8000);
    connect(m_server,
            &QTcpServer::newConnection,
            this,
            &MyServer::connRecvd);
}

void MyServer::connRecvd()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_clientSock =m_server->nextPendingConnection();
    connect(m_clientSock,&QTcpSocket::readyRead,
            this,&MyServer::dataRecved);
    m_clientSock->write("hello");

}

void MyServer::dataRecved()
{
     qDebug()<<"Data Recved"<<m_clientSock->readAll()<<Qt::endl;
}
