#ifndef MYPHONESTATEBULIDER_H
#define MYPHONESTATEBULIDER_H

#include <QObject>

class MyPhoneStateBulider
{
    Q_OBJECT
public:
    MyPhoneStateBulider();
};

#endif // MYPHONESTATEBULIDER_H
