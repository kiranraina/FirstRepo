#include "Myphonesstatehandling.h"

MyPhonesStateHandling::MyPhonesStateHandling(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void MyPhonesStateHandling::buildSM()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;

    QStateMachine *machine=new QStateMachine;

    //Different state initial
    QState *s1=new QState;
    QState *s2=new QState;
    QState *s3=new QState;
    QState *s4=new QState;
    QState *s5=new QState;

    //connection making
    connect(s1,&QState::entered,this,&MyPhonesStateHandling::callRecved);
    connect(s2,&QState::entered,this,&MyPhonesStateHandling::callSpeaking);
    connect(s3,&QState::entered,this,&MyPhonesStateHandling::callSwap);
    connect(s4,&QState::entered,this,&MyPhonesStateHandling::callSpeaker);
    connect(s5,&QState::entered,this,&MyPhonesStateHandling::callEnd);

    //Add state to state machine
    machine->addState(s1);
    machine->addState(s2);
    machine->addState(s3);
    machine->addState(s4);
    machine->addState(s5);

    //initial state set
    machine->setInitialState(s1);

    //jump one state to another use addtransition
    s1->addTransition(this,&MyPhonesStateHandling::calldone,s2);
    s2->addTransition(this,&MyPhonesStateHandling::callConference,s3);
    s3->addTransition(this,&MyPhonesStateHandling::callrecord,s4);
    s4->addTransition(this,&MyPhonesStateHandling::callDisconnect,s5);

    //machine start
    machine->start();

}
void MyPhonesStateHandling::callRecved(){

    qDebug()<<Q_FUNC_INFO<<"call recived now"<<Qt::endl;
    emit calldone();
}
void MyPhonesStateHandling::callSpeaking(){

    qDebug()<<Q_FUNC_INFO<<"callSpeaking now"<<Qt::endl;
    emit callConference();
}
void MyPhonesStateHandling::callSwap(){

    qDebug()<<Q_FUNC_INFO<<"callSwap now"<<Qt::endl;
    emit callrecord();
}
void MyPhonesStateHandling::callSpeaker(){

    qDebug()<<Q_FUNC_INFO<<"callSpeaker now"<<Qt::endl;
    emit callDisconnect();
}
void MyPhonesStateHandling::callEnd(){

    qDebug()<<Q_FUNC_INFO<<"callEnd now"<<Qt::endl;
}
