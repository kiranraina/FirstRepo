#ifndef MYPHONESSTATEHANDLING_H
#define MYPHONESSTATEHANDLING_H
#include<QDebug>
#include <QObject>
#include<QStateMachine>
class MyPhonesStateHandling : public QObject
{
    Q_OBJECT
public:
    explicit MyPhonesStateHandling(QObject *parent = nullptr);
    void buildSM();
public slots:
    void callRecved();
    void callSpeaking();
    void callSwap();
    void callSpeaker();
    void callEnd();
signals:
   void calldone();
   void callConference();
   void callrecord();
   void callDisconnect();
};

#endif // MYPHONESSTATEHANDLING_H
