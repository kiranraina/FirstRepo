#ifndef MYSERVER_H
#define MYSERVER_H
#include<QTcpServer>
#include<QTcpSocket>
#include<QDebug>
#include <QObject>

class MyServer : public QObject
{
    Q_OBJECT
public:
    explicit MyServer(QObject *parent = nullptr);
    Q_INVOKABLE void init();
    void connRecvd();
    void dataRecved();

signals:
private:
    QTcpServer *m_server;
    QTcpSocket *m_clientSock;
};

#endif // MYSERVER_H
