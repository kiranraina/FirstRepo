#include "mbserver.h"

MbServer::MbServer(QObject *parent)
    : QObject{parent}
{

}
