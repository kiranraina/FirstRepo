#ifndef MBSERVER_H
#define MBSERVER_H

#include <QObject>

class MbServer : public QObject
{
    Q_OBJECT
public:
    explicit MbServer(QObject *parent = nullptr);

signals:

};

#endif // MBSERVER_H
