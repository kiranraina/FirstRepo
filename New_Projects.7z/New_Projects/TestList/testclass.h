#ifndef TESTCLASS_H
#define TESTCLASS_H


class TestClass
{
public:
    TestClass();
    int a;
};

#endif // TESTCLASS_H
