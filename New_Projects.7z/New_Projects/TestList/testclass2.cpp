#include "testclass2.h"
#include "qdebug.h"
#include "qlist.h"

TestClass2::TestClass2()
{
    QList<TestClass> tcl;
    TestClass tc;
    tc.a = 10;
    tcl.append(tc);
    tc.a = 20;
    tcl.append(tc);
    m_tcll = tcl;
}
