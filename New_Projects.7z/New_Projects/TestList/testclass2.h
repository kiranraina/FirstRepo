#ifndef TESTCLASS2_H
#define TESTCLASS2_H
#include "qlist.h"
#include "testclass.h"


class TestClass2
{
public:
    TestClass2();
    QList<TestClass> m_tcll;
};

#endif // TESTCLASS2_H
