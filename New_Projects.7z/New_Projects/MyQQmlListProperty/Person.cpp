#include "Person.h"
#include <QDebug>

Person::Person(QObject *parent)
    : QObject{parent}
{
  qDebug()<<"Person constructor";
}

const QString &Person::name() const
{
    return m_name;
}

void Person::setName(const QString &newName)
{
    m_name = newName;
    emit nameChanged();
}

int Person::shoeSize() const
{
    return m_shoeSize;
}

void Person::setShoeSize(const int &size)
{
  m_shoeSize=size;
  emit shoesizeChanged();
}
