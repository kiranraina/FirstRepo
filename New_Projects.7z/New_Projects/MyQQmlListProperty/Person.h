#ifndef PERSON_H
#define PERSON_H

#include <QObject>

class Person : public QObject
{
    Q_OBJECT
public:
    explicit Person(QObject *parent = nullptr);

    const QString &name() const;
    void setName(const QString &newName);

    int shoeSize() const;
    void setShoeSize(const int &size);

signals:
    void shoesizeChanged();
    void nameChanged();
private:
    QString m_name;
    int m_shoeSize;

    Q_PROPERTY(int shoeSize READ shoeSize WRITE setShoeSize NOTIFY shoesizeChanged);
     Q_PROPERTY(QString name READ name WRITE setName NOTIFY nameChanged)
};

#endif // PERSON_H
