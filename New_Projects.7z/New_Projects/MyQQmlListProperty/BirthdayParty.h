#ifndef BIRTHDAYPARTY_H
#define BIRTHDAYPARTY_H

#include <QObject>
#include "Person.h"
#include "QQmlListProperty"
#include <QVector>
class BirthdayParty : public QObject
{
    Q_OBJECT
    Q_PROPERTY(Person *host READ host WRITE setHost)
    Q_PROPERTY(QQmlListProperty<Person> guests READ guests)
public:
    BirthdayParty();

    Person *host() const;
    void setHost(Person *);

    QQmlListProperty<Person> guests();
    void appendGuest(Person*);
    int guestCount() const;
    Person *guest(int) const;
    void clearGuests();
    void replaceGuest(int, Person*);
    void removeLastGuest();

private:
    static void appendGuest(QQmlListProperty<Person>*, Person*);
    static int guestCount(QQmlListProperty<Person>*);
    static Person* guest(QQmlListProperty<Person>*, int);
    static void clearGuests(QQmlListProperty<Person>*);
    static void replaceGuest(QQmlListProperty<Person>*, int, Person*);
    static void removeLastGuest(QQmlListProperty<Person>*);

    Person *m_host;
    QVector<Person *> m_guests;
};

#endif // BIRTHDAYPARTY_H
