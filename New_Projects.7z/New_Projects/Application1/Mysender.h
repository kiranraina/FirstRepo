#ifndef MYSENDER_H
#define MYSENDER_H
#include<QTcpSocket>
#include <QObject>
#include<QDebug>


class Mysender : public QObject
{
    Q_OBJECT
public:
    explicit Mysender(QObject *parent = nullptr);
    Q_INVOKABLE void init();
    Q_INVOKABLE void startConnect();
    Q_INVOKABLE void sendData(QString da);

signals:
private:
    QTcpSocket *m_socket;


};

#endif // MYSENDER_H
