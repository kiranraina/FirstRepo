#include "Mysender.h"

Mysender::Mysender(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    init();
}

void Mysender::init()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_socket=new QTcpSocket;
}

void Mysender::startConnect()
{
   qDebug()<<Q_FUNC_INFO<<Qt::endl;
   this->m_socket->connectToHost("localhost",8000);
}

void Mysender::sendData(QString da)
{
    qDebug()<<Q_FUNC_INFO<<da<<Qt::endl;
    m_socket->write(da.toLocal8Bit().constData());
}
