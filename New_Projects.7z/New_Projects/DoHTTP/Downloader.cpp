#include "Downloader.h"

Downloader::Downloader(QObject *parent)
    : QObject{parent}
{

}
