#ifndef MYRECEIVER_H
#define MYRECEIVER_H
#include<QTcpServer>
#include<QTcpSocket>
#include<QDebug>
#include <QObject>

class Myreceiver : public QObject
{
    Q_OBJECT
public:
    explicit Myreceiver(QObject *parent = nullptr);
    Q_INVOKABLE void init();
    void connRecvd();
    void dataRecved();
    Q_PROPERTY(QString data READ data WRITE setData NOTIFY dataChanged)

    const QString &data() const;
    void setData(const QString &newData);

signals:
    void dataChanged();
private:
    QTcpServer *m_server;
    QTcpSocket *m_clientSock;
    QString m_data;

};

#endif // MYRECEIVER_H
