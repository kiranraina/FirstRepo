#include "Myreceiver.h"

Myreceiver::Myreceiver(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_server=nullptr;
    init();
}

void Myreceiver::init()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    this->m_server=new QTcpServer;
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_server->listen(QHostAddress::Any,8000);
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    connect(m_server,
            &QTcpServer::newConnection,
            this,
            &Myreceiver::connRecvd);
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void Myreceiver::connRecvd()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_clientSock =m_server->nextPendingConnection();
    connect(m_clientSock,&QTcpSocket::readyRead,
            this,&Myreceiver::dataRecved);
}

void Myreceiver::dataRecved()
{
      qDebug()<<Q_FUNC_INFO<<Qt::endl;
      m_data=m_clientSock->readAll();
      qDebug()<<"Data Recved"<<m_data<<Qt::endl;
      emit dataChanged();
}

const QString &Myreceiver::data() const
{
    return m_data;
}

void Myreceiver::setData(const QString &newData)
{
    m_data = newData;

}
