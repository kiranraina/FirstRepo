#ifndef MEDIA_H
#define MEDIA_H
#include<QString>
#include <QObject>
#include<QDebug>
#include <QTimer>
class Media : public QObject
{
    Q_OBJECT
    Q_PROPERTY(type name READ name WRITE setName NOTIFY nameChanged);
    Q_PROPERTY(type id READ id WRITE setId NOTIFY idChanged)
    Q_PROPERTY(type mediaOwner READ mediaOwner WRITE setMediaOwner NOTIFY mediaOwnerChanged)
public:
    explicit Media(QObject *parent = nullptr);

    const QString &name() const;
    void setName(const QString &newName);

    int id() const;
    void setId(int newId);

    const QString &mediaOwner() const;
    void setMediaOwner(const QString &newMediaOwner);
    void init();
    void changes();
signals:
void nameChanged();
void idChanged();
void mediaOwnerChanged();
private:
    QString m_name;
    int m_id;
    QString m_mediaOwner;
    int value;
};

#endif // MEDIA_H
