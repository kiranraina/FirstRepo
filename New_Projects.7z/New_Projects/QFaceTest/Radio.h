#ifndef RADIO_H
#define RADIO_H

#include<QString>
#include <QObject>
#include<QDebug>
#include <QTimer>
class Radio : public QObject
{
    Q_OBJECT
    Q_PROPERTY(type name READ name WRITE setName NOTIFY nameChanged)
    Q_PROPERTY(type id READ id WRITE setId NOTIFY idChanged)
    Q_PROPERTY(type radioOwner READ radioOwner WRITE setRadioOwner NOTIFY radioOwnerChanged)
public:
    explicit Radio(QObject *parent = nullptr);
    const QString &name() const;
    void setName(const QString &newName);

    int id() const;
    void setId(int newId);

    const QString &radioOwner() const;
    void setRadioOwner(const QString &newRadioOwner);
    void init();
    void changes();
signals:
    void nameChanged();
    void idChanged();
    void radioOwnerChanged();
 private:
    QString m_name;
    int m_id;
    QString m_radioOwner;
int value;
};

#endif // RADIO_H
