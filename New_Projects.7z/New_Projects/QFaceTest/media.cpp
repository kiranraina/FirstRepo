#include "Media.h"

Media::Media(QObject *parent)
    : QObject{parent}
{
  qDebug()<<"media constructor"<<Qt::endl;
  value=0;
  this->init();
}

const QString &Media::name() const
{
    return m_name;
}

void Media::setName(const QString &newName)
{
    emit nameChanged();
    m_name = newName;
}

int Media::id() const
{
    return m_id;
}

void Media::setId(int newId)
{
    emit idChanged();
    m_id = newId;
}

const QString &Media::mediaOwner() const
{
    return m_mediaOwner;
}

void Media::setMediaOwner(const QString &newMediaOwner)
{
    emit mediaOwnerChanged();
    m_mediaOwner = newMediaOwner;
}

void Media::init()
{
    qDebug()<<"media init"<<Qt::endl;
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Media::changes);
     timer->start(2000);
}

void Media::changes()
{
    qDebug()<<"Media changes"<<Qt::endl;
    this->setName("kiran"+QString::number(value++));
    this->setId((value++));
    this->setMediaOwner("kumar"+QString::number(value++));
}
