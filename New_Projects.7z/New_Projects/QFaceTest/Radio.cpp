#include "Radio.h"

Radio::Radio(QObject *parent)
    : QObject{parent}
{
 qDebug()<<"radio constructor"<<Qt::endl;
 value=0;
 this->init();
}
const QString &Radio::name() const
{
    return m_name;
}

void Radio::setName(const QString &newName)
{
    emit nameChanged();
    m_name = newName;
}

int Radio::id() const
{
    return m_id;
}

void Radio::setId(int newId)
{
    emit idChanged();
    m_id = newId;
}

const QString &Radio::radioOwner() const
{
    return m_radioOwner;
}

void Radio::setRadioOwner(const QString &newRadioOwner)
{
  emit radioOwnerChanged();
    m_radioOwner = newRadioOwner;
}

void Radio::init()
{
    qDebug()<<"radio init"<<Qt::endl;
    QTimer *timer = new QTimer(this);
    connect(timer, &QTimer::timeout, this, &Radio::changes);
     timer->start(2000);
}

void Radio::changes()
{
    qDebug()<<"radio changes"<<Qt::endl;
    this->setName("kiran"+QString::number(value++));
    this->setId((value++));
    this->setRadioOwner("kumar"+QString::number(value++));
}
