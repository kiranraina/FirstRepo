#include "Person.h"

Person::Person(QObject *parent)
    : QObject{parent}
{
  qDebug()<<"person constructor"<<Qt::endl;
  value=0;
  this->init();
}

const QString &Person::getName() const
{
    return name;
}

void Person::setName(const QString &newName)
{
    emit nameChanged();
    name = newName;
}

int Person::age() const
{
    return m_age;
}

void Person::setAge(int newAge)
{
    emit ageChanged();
    m_age = newAge;
}

const QString &Person::gender() const
{
    return m_gender;
}

void Person::setGender(const QString &newGender)
{
    emit genderChanged();
    m_gender = newGender;
}

void Person::init()
{
  qDebug()<<"person init"<<Qt::endl;
  QTimer *timer = new QTimer(this);
  connect(timer, &QTimer::timeout, this, &Person::changes);
   timer->start(2000);
}

void Person::changes()
{
  qDebug()<<"person changes"<<Qt::endl;
  this->setName("kiran"+QString::number(value++));
  this->setAge(13+(value++));
  this->setGender("male");
}
