#ifndef PERSON_H
#define PERSON_H

#include<QString>
#include <QObject>
#include<QDebug>
#include <QTimer>

class Person : public QObject
{
     Q_OBJECT
     Q_PROPERTY(type name READ name WRITE setName NOTIFY nameChanged);
     Q_PROPERTY(type age READ age WRITE setAge NOTIFY ageChanged);
     Q_PROPERTY(type gender READ gender WRITE setGender NOTIFY genderChanged);
public:
    explicit Person(QObject *parent = nullptr);

    const QString &getName() const;
    void setName(const QString &newName);

    int age() const;
    void setAge(int newAge);

    const QString &gender() const;
    void setGender(const QString &newGender);
    void init();
    void changes();

signals:
    void genderChanged();
    void ageChanged();
    void nameChanged();
private:
    QString name;
    int m_age;
    QString m_gender;
    int value;
};

#endif // PERSON_H
