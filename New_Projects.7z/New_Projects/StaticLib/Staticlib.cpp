#include "Staticlib.h"

StaticLib::StaticLib()
{
   cout<<"StaticLib constructor"<<endl;
}

int StaticLib::addition(int a, int b)
{
   cout<<"addition function called"<<endl;
   return a+b;
}
StaticLib::~StaticLib()
{
   cout<<"StaticLib destructor"<<endl;
}
