#ifndef STATICLIB_H
#define STATICLIB_H
#include "iostream"
using namespace std;
class StaticLib
{
public:
    StaticLib();
    ~StaticLib();
    int addition(int,int);
};

#endif // STATICLIB_H
