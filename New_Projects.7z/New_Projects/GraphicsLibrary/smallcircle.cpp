#include "smallcircle.h"

SmallCircle::SmallCircle()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_colo=QColor(0,255,255);
}

void SmallCircle::paint(QPainter *painter)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QRectF f(20,20,60,60);//x,y,w.h
    painter->setBrush(m_colo);
    painter->setPen(Qt::red);
    painter->drawEllipse(f);
}

const QColor &SmallCircle::colo() const
{
    return m_colo;
}

void SmallCircle::setColo(const QColor &newColo)
{
    m_colo = newColo;
}
