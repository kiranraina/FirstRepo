#ifndef MYCIRCLE_H
#define MYCIRCLE_H
#include<QDebug>
#include <QQuickPaintedItem>
#include <QObject>
#include<QPainter>
#include<QColor>
class Mycircle : public QQuickPaintedItem
{
    Q_OBJECT
    Q_PROPERTY(QColor color READ colors WRITE setColors NOTIFY colorsChanged)
public:
    Mycircle();
    void paint(QPainter *painter);


    const QColor &colors() const;
    void setColors(const QColor &newColors);

signals:
    void colorsChanged();

private:
    QColor m_colors;
};

#endif // MYCIRCLE_H
