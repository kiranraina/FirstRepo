#include "Mycircle.h"

Mycircle::Mycircle()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    m_colors=QColor(0,0,255);
}

void Mycircle::paint(QPainter *painter)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QRectF f(10,10,300,300);//x,y,w.h
    painter->setBrush(m_colors);
    painter->setPen(Qt::red);
    painter->drawEllipse(f);
}

const QColor &Mycircle::colors() const
{
    return m_colors;
}

void Mycircle::setColors(const QColor &newColors)
{
    m_colors = newColors;
}
