#ifndef GRAPHICSLIBRARY_PLUGIN_H
#define GRAPHICSLIBRARY_PLUGIN_H

#include <QQmlExtensionPlugin>

class GraphicsLibraryPlugin : public QQmlExtensionPlugin
{
    Q_OBJECT
    Q_PLUGIN_METADATA(IID QQmlExtensionInterface_iid)

public:
    void registerTypes(const char *uri) override;
};

#endif // GRAPHICSLIBRARY_PLUGIN_H
