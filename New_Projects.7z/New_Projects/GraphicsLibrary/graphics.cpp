#include "graphics.h"

Graphics::Graphics()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void Graphics::paint(QPainter *painter)
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QRectF f1(10,10,300,300);//x,y,w.h
    painter->setBrush(Qt::yellow);
    painter->setPen(Qt::red);
    painter->drawEllipse(f1);
    QRectF f2(50,100,80,40);//x,y,w.h
    painter->setBrush(Qt::white);
    painter->setPen(Qt::red);
    painter->drawEllipse(f2);
    QRectF f3(80,108,20,20);//x,y,w.h
    painter->setBrush(Qt::black);
    painter->setPen(Qt::red);
    painter->drawEllipse(f3);
    QRectF f4(200,100,80,40);//x,y,w.h
    painter->setBrush(Qt::white);
    painter->setPen(Qt::red);
    painter->drawEllipse(f4);
    QRectF f5(230,108,20,20);//x,y,w.h
    painter->setBrush(Qt::black);
    painter->setPen(Qt::red);
    painter->drawEllipse(f5);
    QRectF f(110,110,100,100);//x,y,w.h
    int startAngle = 218 * 16;
    int spanAngle = 100 * 16;
    painter->setBrush(Qt::white);
    painter->setPen(Qt::red);
    painter->drawChord(f, startAngle, spanAngle);
}


