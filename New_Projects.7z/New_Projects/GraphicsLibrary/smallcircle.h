#ifndef SMALLCIRCLE_H
#define SMALLCIRCLE_H

#include<QDebug>
#include <QQuickPaintedItem>
#include <QObject>
#include<QPainter>
#include<QColor>

class SmallCircle : public QQuickPaintedItem
{
    Q_OBJECT
      Q_PROPERTY(QColor colo READ colo WRITE setColo NOTIFY coloChanged)
public:
    SmallCircle();
    void paint(QPainter *painter);
    const QColor &colo() const;

    void setColo(const QColor &newColo);

signals:
    void coloChanged();

private:
    QColor m_colo;
};

#endif // SMALLCIRCLE_H
