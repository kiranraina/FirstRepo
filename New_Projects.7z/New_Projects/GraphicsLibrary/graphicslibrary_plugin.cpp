#include "graphicslibrary_plugin.h"

#include "myitem.h"
#include "graphics.h"
#include "Mycircle.h"
#include "smallcircle.h"
#include <qqml.h>

void GraphicsLibraryPlugin::registerTypes(const char *uri)
{
    // @uri com.mycompany.qmlcomponents
//    qmlRegisterType<MyItem>(uri, 1, 0, "MyItem");
    qmlRegisterType<Graphics>(uri,1,0,"Mycicle");
//    qmlRegisterType<Mycircle>(uri,1,0,"Mycircles");
//    qmlRegisterType<SmallCircle>(uri,1,0,"Smallcircle");
}

