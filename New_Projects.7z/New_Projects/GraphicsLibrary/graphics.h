#ifndef GRAPHICS_H
#define GRAPHICS_H
#include<QDebug>
#include<QQuickPaintedItem>
#include<QObject>
#include<QPainter>
#include<QColor>

class Graphics : public QQuickPaintedItem
{
    Q_OBJECT
public:
    Graphics();
    void paint(QPainter *painter);
signals:
    void colorChanged();
};
#endif // GRAPHICS_H
