#ifndef BASECLASSSTATE_H
#define BASECLASSSTATE_H
#include<QDebug>
#include <QState>

class BaseClassState : public QState
{
public:
    BaseClassState();
    ~BaseClassState();
    virtual bool doWork()=0;
signals:
    void complete();
};

#endif // BASECLASSSTATE_H
