#include "Callreadyreceiver.h"

CallReadyReceiver::CallReadyReceiver()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    connect(this,&CallReadyReceiver::entered,this,&CallReadyReceiver::startInit);
}

bool CallReadyReceiver::doWork()
{
    qDebug()<<Q_FUNC_INFO<<"call Recived"<<Qt::endl;
    qDebug()<<Q_FUNC_INFO<<"move to call Handling"<<Qt::endl;
}
void CallReadyReceiver::startInit()
{
    qDebug()<<Q_FUNC_INFO<<"initialing state"<<Qt::endl;
}
