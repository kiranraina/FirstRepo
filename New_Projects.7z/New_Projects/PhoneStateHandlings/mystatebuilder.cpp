#include "mystatebuilder.h"

MyStateBuilder::MyStateBuilder(QObject *parent)
    : QObject{parent}
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

void MyStateBuilder::buildSM()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
    QStateMachine *machine=new QStateMachine;
    CallReadyReceiver *readystate=new CallReadyReceiver;
    machine->addState(readystate);
    machine->setInitialState(readystate);

    machine->start();
}
