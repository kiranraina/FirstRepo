#ifndef CALLREADYRECEIVER_H
#define CALLREADYRECEIVER_H
#include<Baseclassstate.h>
#include <QObject>

class CallReadyReceiver : public BaseClassState
{
    Q_OBJECT
public:
    CallReadyReceiver();
    bool doWork() override;
public slots:
    void startInit();
};

#endif // CALLREADYRECEIVER_H
