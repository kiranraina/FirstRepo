#include "Baseclassstate.h"

BaseClassState::BaseClassState()
{
    qDebug()<<Q_FUNC_INFO<<Qt::endl;
}

BaseClassState::~BaseClassState()
{
 qDebug()<<Q_FUNC_INFO<<Qt::endl;
}
