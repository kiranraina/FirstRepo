#ifndef MYSTATEBUILDER_H
#define MYSTATEBUILDER_H
#include<QDebug>
#include <QObject>
#include<QStateMachine>
#include"Callreadyreceiver.h"

class MyStateBuilder : public QObject
{
    Q_OBJECT
public:
    explicit MyStateBuilder(QObject *parent = nullptr);
     void buildSM();
signals:

};

#endif // MYSTATEBUILDER_H
