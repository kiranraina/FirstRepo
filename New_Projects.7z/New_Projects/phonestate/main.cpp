#include <iostream>
#include<Phonestate.h>
using namespace std;

int main()
{
    int val;
    cout << "Hello World!" << endl;
    PhoneState phone;
   cout << "Enter the number" << endl;
   cin>>val;
   phone.call(val);
    return 0;
}
