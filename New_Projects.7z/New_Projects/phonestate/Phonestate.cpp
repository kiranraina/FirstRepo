#include "Phonestate.h"

PhoneState::PhoneState()
{
 cout<<"PhoneState constructor"<<endl;
}

void PhoneState::call(int val)
{
  cout<<"PhoneState call function"<<endl;
  if(val<=2&&val>=0){
   cout<<"call ringing"<<endl;
  }else if(val>2&&val<=5){
     cout<<"He is received call"<<endl;
  }else{
     cout<<"He is another call"<<endl;
  }
}
