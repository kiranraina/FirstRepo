#ifndef PHONESTATE_H
#define PHONESTATE_H
#include<iostream>
using namespace std;

class PhoneState
{
public:
    PhoneState();
    void call(int);
};

#endif // PHONESTATE_H
