<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="9"/>
        <source>Hello World</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="16"/>
        <source>Welcome</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="21"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="26"/>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="31"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="36"/>
        <source>Projects</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="main.qml" line="41"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
