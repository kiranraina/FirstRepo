<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="kn_IN" sourcelanguage="en_IN">
<context>
    <name>main</name>
    <message>
        <location filename="main.qml" line="9"/>
        <source>Hello World</source>
        <translation>ನಮಸ್ಕಾರ</translation>
    </message>
    <message>
        <location filename="main.qml" line="16"/>
        <source>Welcome</source>
        <translation>ಸ್ವಾಗತ</translation>
    </message>
    <message>
        <location filename="main.qml" line="21"/>
        <source>Edit</source>
        <translation>ತಿದ್ದು</translation>
    </message>
    <message>
        <location filename="main.qml" line="26"/>
        <source>Design</source>
        <translation>ವಿನ್ಯಾಸ</translation>
    </message>
    <message>
        <location filename="main.qml" line="31"/>
        <source>Debug</source>
        <translation>ಡೀಬಗ್</translation>
    </message>
    <message>
        <location filename="main.qml" line="36"/>
        <source>Projects</source>
        <translation>ಯೋಜನೆ</translation>
    </message>
    <message>
        <location filename="main.qml" line="41"/>
        <source>Help</source>
        <translation>ಸಹಾಯ</translation>
    </message>
</context>
</TS>
