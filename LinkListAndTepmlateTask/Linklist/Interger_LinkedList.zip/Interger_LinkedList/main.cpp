#include <iostream>
#include<IntLinkList.h>
using namespace std;

int main(int argc, char *argv[])
{
    IntLinkList linklist;
    linklist.init();
    return 0;
}
