#include <iostream>
#include<StudentList.h>
using namespace std;

int main(int argc, char *argv[])
{
    StudentList stu;
    cout << "Hello World!" << endl;
    return 0;
}
