#include <iostream>
#include<FloatLink.h>
using namespace std;

int main(int argc, char *argv[])
{
    FloatLink floatlink;
    cout << "Hello World!" << endl;
    return 0;
}
