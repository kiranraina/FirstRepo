#include <iostream>
#include<StringList.h>
using namespace std;

int main(int argc, char *argv[])
{
    StringList str;
    cout << "Hello World!" << endl;
    return 0;
}
