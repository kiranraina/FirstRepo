#include <iostream>
#include<DoubleLinkList.h>
using namespace std;

int main(int argc, char *argv[])
{
    DoubleLinkList DoublList;
    cout << "Hello World!" << endl;
    return 0;
}
